from st3215 import ST3215
import socket
import network
import time
import _thread
from machine import Pin

# # WiFi settings
# SSID = "PHY_AI"
# PASSWORD = "PHY_AI@IHR"
# 
# # Connect to WiFi
# wlan = network.WLAN(network.STA_IF)
# wlan.active(True)
# try:
#     wlan.config(hostname="leader2")
# except:
#     pass
# 
# wlan.connect(SSID, PASSWORD)
# 
# while not wlan.isconnected():
#     time.sleep(1)
# 
# print("Connected!")
# print("IP:", wlan.ifconfig()[0])
import network

wlan = network.WLAN(network.STA_IF)

try:
    wlan.config(hostname="leader2")
except:
    pass

print("WiFi OK" if wlan.isconnected() else "WiFi NOT connected")

if wlan.isconnected():
    print("IP:", wlan.ifconfig()[0])

# Start web server...
servo = ST3215(
    uart_id=2,
    tx_pin=17,
    rx_pin=16,
    baudrate=1000000
)

CENTER = 2048

# ==========================
# UDP TELEMETRY THREAD
# ==========================

UDP_HOST = "daksha.local"      # follower PC hostname or mDNS name
UDP_PORT = 5005

udp = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
udp_addr = socket.getaddrinfo(UDP_HOST, UDP_PORT)[0][-1]
servo_lock = _thread.allocate_lock()

# Buttons (GPIO pins can be changed to match your wiring)
btn1 = Pin(25, Pin.IN, Pin.PULL_DOWN)
btn2 = Pin(26, Pin.IN, Pin.PULL_DOWN)
btn3 = Pin(27, Pin.IN, Pin.PULL_DOWN)

def read_servo_position(sid):
    try:
        servo_lock.acquire()
        pos = servo.ReadPosition(sid)
#         print("ID", sid, "RAW:", pos)
        if pos is None:
            pos = -1
    except Exception as e:
        print("ID", sid, "ERROR:", e)
        pos = -1
    finally:
        servo_lock.release()
    return pos

def udp_task():
    while True:
        packet = []
        for sid in range(1,17):
            pos = read_servo_position(sid)
            packet.append("{},{}".format(sid, pos))

        # Read button states and append to packet
        try:
            b1 = btn1.value()
            b2 = btn2.value()
            b3 = btn3.value()
        except Exception as e:
            print("Buttons read ERROR:", e)
            b1 = b2 = b3 = 0

        packet.append("B1,{}".format(b1))
        packet.append("B2,{}".format(b2))
        packet.append("B3,{}".format(b3))

        msg = ";".join(packet)
#         try:
        udp.sendto(msg.encode(), udp_addr)
#         except Exception as e:
#             print("UDP:", e)
# 
#         time.sleep_ms(50)     # 20Hz

_thread.start_new_thread(udp_task, ())
print("UDP thread started")

def define_middle(sts_id):
    try:
        return servo.DefineMiddle(sts_id)
    except:
        return None

html = open("index.html").read()

addr = socket.getaddrinfo("0.0.0.0",80)[0][-1]

s=socket.socket()
s.bind(addr)
s.listen(1)

print("Web Server Ready")

while True:

    cl,addr=s.accept()

    req = cl.recv(1024)

    if not req:
        cl.close()
        continue

    req = req.decode()

    try:
        line = req.split("\r\n")[0]
        path = line.split(" ")[1]
    except:
        cl.close()
        continue

    print(path)
    if path == "/favicon.ico":
        cl.send("HTTP/1.1 204 No Content\r\n\r\n")
        cl.close()
        continue
    response=html

    if path=="/enableall":

        for i in range(1,17):
            try:
                servo_lock.acquire()
                servo.StartServo(i)
            except Exception as e:
                print("StartServo", i, "ERROR:", e)
            finally:
                servo_lock.release()

        response="Torque Enabled"

    elif path=="/disableall":

        for i in range(1,17):
            try:
                servo_lock.acquire()
                servo.StopServo(i)
            except Exception as e:
                print("StopServo", i, "ERROR:", e)
            finally:
                servo_lock.release()

        response="Torque Disabled"

    elif path=="/sethome":

        for i in range(1,17):
            try:
                servo_lock.acquire()
                define_middle(i)
            except Exception as e:
                print("DefineMiddle", i, "ERROR:", e)
            finally:
                servo_lock.release()

        response="Home position set for all servos"

    elif path=="/gohome":

        for i in range(1,17):
            try:
                servo_lock.acquire()
                servo.MoveTo(i, CENTER)
            except Exception as e:
                print("MoveTo", i, "ERROR:", e)
            finally:
                servo_lock.release()

        response="All servos moved home"

    if path=="/":

        cl.send("HTTP/1.1 200 OK\r\n")
        cl.send("Content-Type:text/html\r\n\r\n")
        cl.send(response)

    else:

        cl.send("HTTP/1.1 200 OK\r\n")
        cl.send("Content-Type:text/plain\r\n\r\n")
        cl.send(response)

    cl.close()
